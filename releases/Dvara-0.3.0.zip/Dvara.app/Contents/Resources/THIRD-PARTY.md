# Dvara 에 같이 들어가는 오픈소스 (라이선스 · 소스)

앱 안 `Contents/MacOS` · `Contents/Frameworks` · `Contents/Resources/vm` 에 들어갑니다. 버전은 빌드할 때의 것이 `Contents/Resources/vm/SOURCES.txt` 에 적힙니다.
Dvara 자체 소스는 비공개입니다. Dvara 코드는 QEMU 를 **별도 프로세스로 실행**하고 unix 소켓(QMP · VNC)으로만 다룹니다 — QEMU 코드와 링크하지 않습니다.

## 소스 제공 (GPL · LGPL)

**https://github.com/d2ntr5/dvara-qemu** (0.3.0 부터 릴리즈 `qemu-10.0.12-dvara2`, 0.1 ~ 0.2 는 `dvara1`) — 앱에 넣은 QEMU 의 대응 소스 전체(utmapp/qemu `v10.0.12-utm` 그대로 + Dvara 수정 커밋 하나)와 빌드 명령,
같이 넣은 LGPL 라이브러리(glib · gettext/libintl · json-glib)의 그 버전 원본 소스 묶음을 릴리즈 파일로 둡니다. 바꾼 라이브러리는 없습니다.
LGPL 라이브러리는 앱 안에서 따로 된 동적 라이브러리(`Contents/Frameworks/*.dylib`)라 같은 이름의 파일로 바꿔 끼울 수 있습니다.

| 구성 | 라이선스 | 소스 |
|---|---|---|
| QEMU (qemu-system-aarch64 · qemu-system-x86_64(0.3.0) · qemu-img · kvmvapic.bin), utmapp/qemu 갈래 + Dvara 수정 | GPL-2.0 (일부 파일 GPL-2.0-or-later 등, 소스 `LICENSE` · `COPYING`) | https://github.com/d2ntr5/dvara-qemu |
| swtpm (가상 TPM 2.0) | BSD-3-Clause | https://github.com/stefanberger/swtpm |
| libtpms | BSD-2-Clause | https://github.com/stefanberger/libtpms |
| EDK II 펌웨어 (edk2-aarch64-secure-code.fd · edk2-x86_64-secure-code.fd · vars) | BSD-2-Clause-Patent (`Resources/vm/edk2-licenses.txt`) | https://github.com/tianocore/edk2 (QEMU 소스 `pc-bios/` 에 든 빌드) |
| 보안 부팅 키(vars-template.qcow2 · vars-template-x64.qcow2 안의 Microsoft PK · KEK · DB 인증서) | Microsoft 공개 인증서. Red Hat virt-firmware 로 넣음(빌드 때만 씀, 앱에 안 들어감) | https://gitlab.com/kraxel/virt-firmware |
| glib (libglib · libgio · libgobject · libgmodule) | LGPL-2.1-or-later | https://download.gnome.org/sources/glib/ |
| gettext (libintl) | LGPL-2.1-or-later | https://ftp.gnu.org/gnu/gettext/ |
| json-glib | LGPL-2.1-or-later | https://download.gnome.org/sources/json-glib/ |
| pcre2 | BSD-3-Clause | https://github.com/PCRE2Project/pcre2 |
| pixman | MIT | https://cairographics.org/releases/ |
| zstd | BSD-3-Clause (GPL-2.0-only 와 이중) | https://github.com/facebook/zstd |
| libslirp | BSD-3-Clause | https://gitlab.freedesktop.org/slirp/libslirp |
| OpenSSL (libcrypto, swtpm 이 씀) | Apache-2.0 | https://github.com/openssl/openssl |
| spice-protocol (QEMU 빌드 때 헤더만) | BSD-3-Clause | https://www.spice-space.org/ |
| Sparkle (앱 안 업데이트) | MIT | https://github.com/sparkle-project/Sparkle |

## 앱에 넣지 않는 것

- **UTM 게스트 도구**(utm-guest-tools-0.1.271.iso: SPICE 설치 파일 zlib/libpng · vd_agent GPL-3.0 · spice-webdavd LGPL-2.1 · virtio-win 드라이버 BSD-3-Clause):
  처음 VM 을 만들 때 앱이 UTM 공식 주소(`github.com/utmapp/qemu/releases/download/v10.0.2-utm/utm-guest-tools-0.1.271.iso`)에서 받고 SHA-256 을 확인합니다.
- **Windows 11 ISO(Arm64 · x64) · 라이선스**: 사용자가 Microsoft 에서 직접 받고, 제품 키도 사용자가 넣습니다.
